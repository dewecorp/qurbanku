param(
  [string]$Message = "",
  [string]$RemoteUrl = "https://github.com/dewecorp/qurbanku.git",
  [string]$Branch = "main"
)

$ErrorActionPreference = "Stop"

$defaultMessage = if ($Message) { $Message } else { "Update QurbanKu app" }
$inputMessage = Read-Host "Masukkan nama/pesan commit (Enter untuk: $defaultMessage)"
if ($inputMessage.Trim()) {
  $Message = $inputMessage.Trim()
} else {
  $Message = $defaultMessage
}

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location $root

Write-Host "Folder kerja: $root"

$backupDir = Join-Path $root "backups"
if (-not (Test-Path $backupDir)) {
  New-Item -ItemType Directory -Path $backupDir | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$zipPath = Join-Path $backupDir "qurbanku-backup-$timestamp.zip"
$backupItems = @(
  "index.html",
  "Code_simple.gs",
  "qurbanku-blogger-theme.xml",
  "backup-commit-push.bat",
  "scripts"
)

$backupPaths = @()
foreach ($item in $backupItems) {
  $itemPath = Join-Path $root $item
  if (Test-Path $itemPath) {
    $backupPaths += $itemPath
  }
}

Write-Host "Membuat backup ZIP..."
Compress-Archive -Path $backupPaths -DestinationPath $zipPath -Force
Write-Host "Backup dibuat: $zipPath"

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  throw "Git tidak ditemukan di PATH. Install Git for Windows dulu."
}

$gitDir = Join-Path $root ".git"
$isRepo = $false
git rev-parse --is-inside-work-tree *> $null
if ($LASTEXITCODE -eq 0) {
  $isRepo = $true
}

if (-not $isRepo) {
  if ((Test-Path $gitDir) -and -not (Test-Path (Join-Path $gitDir "HEAD"))) {
    Write-Host "Folder .git kosong/rusak terdeteksi. Menghapus .git lama sebelum git init..."
    Remove-Item -LiteralPath $gitDir -Recurse -Force
  }
  Write-Host "Inisialisasi repository Git lokal..."
  git init
}

$remoteExists = $false
git remote get-url origin *> $null
if ($LASTEXITCODE -eq 0) {
  $remoteExists = $true
}

if ($remoteExists) {
  git remote set-url origin $RemoteUrl
} else {
  git remote add origin $RemoteUrl
}
Write-Host "Remote origin: $RemoteUrl"

$gitName = git config user.name
if (-not $gitName) {
  git config user.name "dewecorp"
}

$gitEmail = git config user.email
if (-not $gitEmail) {
  git config user.email "dewecorp@users.noreply.github.com"
}

git add index.html Code_simple.gs qurbanku-blogger-theme.xml backup-commit-push.bat scripts backups

$hasChanges = $false
git diff --cached --quiet
if ($LASTEXITCODE -ne 0) {
  $hasChanges = $true
}

if ($hasChanges) {
  git commit -m $Message
} else {
  Write-Host "Tidak ada perubahan untuk commit."
}

git branch -M $Branch

Write-Host "Status Git sebelum push:"
git status --short --branch

git ls-remote --exit-code --heads origin $Branch *> $null
if ($LASTEXITCODE -eq 0) {
  git pull --rebase --autostash origin $Branch
}

Write-Host "Mulai push ke GitHub. Jika diminta login, ikuti popup Git Credential Manager/GitHub."
git push -u origin $Branch

Write-Host "Selesai: backup, commit, dan push ke $RemoteUrl branch $Branch"
