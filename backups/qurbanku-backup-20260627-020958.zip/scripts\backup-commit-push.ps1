param(
  [string]$Message = "Update QurbanKu app",
  [string]$RemoteUrl = "https://github.com/dewecorp/qurbanku.git",
  [string]$Branch = "main"
)

$ErrorActionPreference = "Stop"

$root = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location $root

$backupDir = Join-Path $root "backups"
if (-not (Test-Path $backupDir)) {
  New-Item -ItemType Directory -Path $backupDir | Out-Null
}

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$zipPath = Join-Path $backupDir "qurbanku-backup-$timestamp.zip"
$tempDir = Join-Path ([System.IO.Path]::GetTempPath()) "qurbanku-backup-$timestamp"

if (Test-Path $tempDir) {
  Remove-Item -LiteralPath $tempDir -Recurse -Force
}
New-Item -ItemType Directory -Path $tempDir | Out-Null

Get-ChildItem -LiteralPath $root -Force | Where-Object {
  $_.Name -notin @(".git", "backups")
} | ForEach-Object {
  Copy-Item -LiteralPath $_.FullName -Destination $tempDir -Recurse -Force
}

Compress-Archive -Path (Join-Path $tempDir "*") -DestinationPath $zipPath -Force
Remove-Item -LiteralPath $tempDir -Recurse -Force
Write-Host "Backup dibuat: $zipPath"

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  throw "Git tidak ditemukan di PATH. Install Git for Windows dulu."
}

git rev-parse --is-inside-work-tree *> $null
if ($LASTEXITCODE -ne 0) {
  git init
}

$remoteExists = $false
git remote get-url origin *> $null
if ($LASTEXITCODE -eq 0) {
  $remoteExists = $true
}

if ($remoteExists) {
  git remote set-url origin $RemoteUrl
} else {
  git remote add origin $RemoteUrl
}

$gitName = git config user.name
if (-not $gitName) {
  git config user.name "dewecorp"
}

$gitEmail = git config user.email
if (-not $gitEmail) {
  git config user.email "dewecorp@users.noreply.github.com"
}

git add index.html Code_simple.gs qurbanku-blogger-theme.xml scripts
git add backups

$hasChanges = $false
git diff --cached --quiet
if ($LASTEXITCODE -ne 0) {
  $hasChanges = $true
}

if ($hasChanges) {
  git commit -m $Message
} else {
  Write-Host "Tidak ada perubahan untuk commit."
}

git branch -M $Branch

git ls-remote --exit-code --heads origin $Branch *> $null
if ($LASTEXITCODE -eq 0) {
  git pull --rebase --autostash origin $Branch
}

git push -u origin $Branch

Write-Host "Selesai: backup, commit, dan push ke $RemoteUrl branch $Branch"
